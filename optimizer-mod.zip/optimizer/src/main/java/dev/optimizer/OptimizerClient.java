package dev.optimizer;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class OptimizerClient implements ClientModInitializer {
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        // 1.21.9+ : KeyBinding artik String yerine Category istiyor
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.optimizer.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_V,
            KeyBinding.Category.create(Identifier.of("optimizer", "main"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                VelocityModule.enabled = !VelocityModule.enabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("Velocity: " + (VelocityModule.enabled ? "ON" : "OFF")), true);
                }
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("velocity")
                .then(ClientCommandManager.literal("on").executes(c -> {
                    VelocityModule.enabled = true;
                    c.getSource().sendFeedback(Text.literal("Velocity: ON"));
                    return 1;
                }))
                .then(ClientCommandManager.literal("off").executes(c -> {
                    VelocityModule.enabled = false;
                    c.getSource().sendFeedback(Text.literal("Velocity: OFF"));
                    return 1;
                }))
                .then(ClientCommandManager.literal("h")
                    .then(ClientCommandManager.argument("v", DoubleArgumentType.doubleArg(0, 1)).executes(c -> {
                        VelocityModule.horizontal = DoubleArgumentType.getDouble(c, "v");
                        c.getSource().sendFeedback(Text.literal("Horizontal: " + VelocityModule.horizontal));
                        return 1;
                    })))
                .then(ClientCommandManager.literal("v")
                    .then(ClientCommandManager.argument("v", DoubleArgumentType.doubleArg(0, 1)).executes(c -> {
                        VelocityModule.vertical = DoubleArgumentType.getDouble(c, "v");
                        c.getSource().sendFeedback(Text.literal("Vertical: " + VelocityModule.vertical));
                        return 1;
                    })))
            ));
    }
}
