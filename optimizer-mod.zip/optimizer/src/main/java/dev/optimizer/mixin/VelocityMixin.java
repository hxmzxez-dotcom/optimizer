package dev.optimizer.mixin;

import dev.optimizer.VelocityModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class VelocityMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void optimizer$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        // Network thread'inde dokunma, ana thread'e yonlendirilince tekrar gelir
        if (!mc.isOnThread()) return;
        if (!VelocityModule.enabled || mc.player == null) return;
        if (packet.getEntityId() != mc.player.getId()) return;

        ci.cancel();
        Vec3d v = packet.getVelocity();
        if (VelocityModule.horizontal > 0 || VelocityModule.vertical > 0) {
            mc.player.setVelocity(v.x * VelocityModule.horizontal,
                                  v.y * VelocityModule.vertical,
                                  v.z * VelocityModule.horizontal);
        }
    }
}
