package dev.optimizer;

public class VelocityModule {
    public static boolean enabled = true;
    public static double horizontal = 0.0; // 0.0 = hic knockback, 1.0 = normal
    public static double vertical = 0.0;
}
